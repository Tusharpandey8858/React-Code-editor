It is a code editor where you can write codes in Html, Css and Javascript.

Clone this repo using `git clone <url>`

And run the following command:

### `npm start`

Runs the app in the development mode.<br />

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The bellow output will be shown to your browser:


<img width="960" alt="image" src="https://user-images.githubusercontent.com/84653396/215846710-12f6e534-e4e7-4bc6-b1d7-eb5c7e20a5c9.png">

